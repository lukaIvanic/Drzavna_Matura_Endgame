package com.example.drzavnamatura_endgame;

public class Util {
    public static final String matA = "Mat A";
    public static final String matB = "Mat B";
    public static final String hrvB = "Hrv B";
    public static final String hrvA = "Hrv A";
    public static final String engB = "Eng B";
    public static final String engA = "Eng A";
    public static final String PRVI_RAZRED = "1. Razred";
    public static final String DRUGI_RAZRED = "2. Razred";
    public static final String TRECI_RAZRED = "3. Razred";
    public static final String CETVRTI_RAZRED = "4. Razred";
    public static final String TIP_LEKCIJA = "Lekcija";
    public static final Boolean TIP_GRADIVO = true;
    public static final String ALL = "all";

}
