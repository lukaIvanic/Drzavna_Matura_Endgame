package com.example.drzavnamatura_endgame;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.TextView;
import android.widget.Toast;
import com.example.drzavnamatura_endgame.MainFragments.CompeteFragment;
import com.example.drzavnamatura_endgame.MainFragments.GradivaFragment;
import com.example.drzavnamatura_endgame.MainFragments.HomeFragment;
import com.example.drzavnamatura_endgame.MainFragments.ProfileFragment;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;


public class MainMenuActivity extends AppCompatActivity {

    FirebaseUser currentUser;
    FirebaseAuth mAuth;

    public static String gradivoPosition;
    BottomNavigationView bottomNavigationView;


    boolean pressed;
    public static Fragment currentF;
    public static int kojiFragment = 0;

    public static String currentUserUsername = "";
    public static String currentUserEmail = "";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_main_menu);
        mAuth = FirebaseAuth.getInstance();
        currentUser = mAuth.getCurrentUser();
        bottomNavigationView = findViewById(R.id.bottomNavigationBar);
        currentUserUsername = currentUser.getDisplayName();
        currentUserEmail = currentUser.getEmail();

        currentF = HomeFragment.newInstance("", "");



        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                switch (item.getItemId()) {
                    case R.id.navigation_home:
                        pressed = false;
                        kojiFragment = 0;
                        getSupportFragmentManager().popBackStack();
                        currentF = HomeFragment.newInstance("", "");
                        openFragment(currentF);
                        return true;
                    case R.id.navigation_compete:
                        getSupportFragmentManager().popBackStack();
                        currentF = CompeteFragment.newInstance("", "");
                        openFragment(currentF);
                        return true;
                    case R.id.navigation_profile:
                        getSupportFragmentManager().popBackStack();
                        currentF = ProfileFragment.newInstance("", "");
                        openFragment(currentF);
                        return true;
                }
                return false;
            }
        });
        openFragment(currentF);
    }


    public void openFragment(Fragment fragment) {
        FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
        transaction.replace(R.id.fragment_container, fragment);
        transaction.commit();
    }


    public void openToolbarActivity(View view) {
        switch (view.getId()) {
            case R.id.shopButton:
                Intent intent = new Intent(MainMenuActivity.this, ShopActivity.class);
                startActivity(intent);
                break;
            case R.id.settingsButton:
                Intent intent1 = new Intent(MainMenuActivity.this, SettingsActivity.class);
                startActivity(intent1);
                break;
        }
    }

    public void openGradiva(View v) {
        GradivaFragment gradivaFragment = new GradivaFragment();
        FragmentManager fragmentManager1 = getSupportFragmentManager();
        FragmentTransaction fragmentTransaction1 = fragmentManager1.beginTransaction();
        kojiFragment = 1;
        fragmentTransaction1.addToBackStack(null);
        fragmentTransaction1.remove(currentF);
        currentF = gradivaFragment;
        fragmentTransaction1.add(R.id.fragment_container, gradivaFragment, "gradiva").commit();

    }

    @Override
    public void onBackPressed() {


        switch (kojiFragment) {
            case 0:
                if (!pressed) {
                    Toast.makeText(this, "Press again to exit", Toast.LENGTH_SHORT).show();
                    pressed = true;
                } else {
                    super.onBackPressed();
                }

                break;
            case 1:
                kojiFragment = 0;
                getSupportFragmentManager().popBackStack();
                currentF = HomeFragment.newInstance("", "");
                openFragment(currentF);
                pressed = false;
                break;
            case 2:
                GradivaFragment gradivaFragment = new GradivaFragment();
                FragmentManager fragmentManager1 = getSupportFragmentManager();
                FragmentTransaction fragmentTransaction1 = fragmentManager1.beginTransaction();
                kojiFragment = 1;
                fragmentTransaction1.addToBackStack(null);
                fragmentTransaction1.remove(currentF);
                currentF = gradivaFragment;
                fragmentTransaction1.add(R.id.fragment_container, gradivaFragment, "gradiva").commit();

                break;


        }


    }

    public void signOut(View view){
        mAuth.signOut();
        Intent intent = new Intent(MainMenuActivity.this, MainActivity.class);
        startActivity(intent);
    }


}
