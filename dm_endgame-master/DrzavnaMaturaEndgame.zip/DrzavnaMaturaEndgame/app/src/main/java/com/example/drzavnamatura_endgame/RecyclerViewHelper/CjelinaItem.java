package com.example.drzavnamatura_endgame.RecyclerViewHelper;

public class CjelinaItem {

    private String naslovCjelina;

    public CjelinaItem (){

    }

    public CjelinaItem(String naslovCjelina) {
        this.naslovCjelina = naslovCjelina;
    }

    public String getNaslovCjelina() {
        return naslovCjelina;
    }

    public void setNaslovCjelina(String naslovCjelina) {
        this.naslovCjelina = naslovCjelina;
    }
}
