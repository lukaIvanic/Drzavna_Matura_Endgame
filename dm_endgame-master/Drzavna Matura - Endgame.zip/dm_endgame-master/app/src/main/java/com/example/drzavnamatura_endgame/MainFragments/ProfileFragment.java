package com.example.drzavnamatura_endgame.MainFragments;

import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.os.Bundle;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;


import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;


import com.example.drzavnamatura_endgame.MainActivity;
import com.example.drzavnamatura_endgame.MainMenuActivity;
import com.example.drzavnamatura_endgame.R;


import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;


import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.List;
import java.util.Objects;


public class ProfileFragment extends Fragment {
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";
    ImageView profilePictureImageView;

    FirebaseFirestore db = FirebaseFirestore.getInstance();
    FirebaseUser currentUser;
    FirebaseAuth mAuth;
    private CollectionReference usersCollectionRef = db.collection("users");


    private String mParam1;
    private String mParam2;

    private TextView username_profileFragment;
    private TextView email_profileFragment;

    private Button settingsButton;

    String completeInfo2 = "";


    public ProfileFragment() {
    }

    public static ProfileFragment newInstance(String param1, String param2) {
        ProfileFragment fragment = new ProfileFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);

        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
        mAuth = FirebaseAuth.getInstance();
        currentUser = mAuth.getCurrentUser();

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        return inflater.inflate(R.layout.fragment_profile, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        username_profileFragment = view.findViewById(R.id.username_textView_profile);
        email_profileFragment = view.findViewById(R.id.email_textView_profile);
        settingsButton = view.findViewById(R.id.profle_settings_button);
        profilePictureImageView = view.findViewById(R.id.slikaProfila);


        if (!MainActivity.completeInfo2.isEmpty()) {
            username_profileFragment.setText(MainActivity.completeInfo2);
            //username_profileFragment.setText(currentUser.getDisplayName() + ", Score: ");
        } else {
            username_profileFragment.setText(MainMenuActivity.completeInfo);
        }

        email_profileFragment.setText(MainMenuActivity.currentUserEmail);


        super.onViewCreated(view, savedInstanceState);
    }


}
