package com.example.drzavnamatura_endgame;

public class Lekcija {
    String Naslov = "", sadrzaj = "";
    String slikaURL = "";
    String TIP_LEKCIJE = "0";
    public static final String SAMO_NASLOV = "0";
    public static final String NASLOV_SADRZAJ = "1";
    public static final String NASLOV_SADRZAJ_SLIKA = "2";


    public Lekcija() {

    }

    public Lekcija(String naslov) {
        this.Naslov = naslov;
        TIP_LEKCIJE = SAMO_NASLOV;
    }

    public Lekcija(String naslov, String sadrzaj) {
        this.Naslov = naslov;
        this.sadrzaj = sadrzaj;
        TIP_LEKCIJE = NASLOV_SADRZAJ;
    }


    public Lekcija(String naslov, String sadrzaj, String slika) {
        this.Naslov = naslov;
        this.sadrzaj = sadrzaj;
        this.slikaURL = slika;
        TIP_LEKCIJE = NASLOV_SADRZAJ_SLIKA;
    }

    public String getNaslov() {
        return Naslov;
    }

    public String getTIP_LEKCIJE() {
        return TIP_LEKCIJE;
    }

    public String getSadrzaj() {
        return sadrzaj;
    }

    public String getSlikaURL() {
        return slikaURL;
    }
}
