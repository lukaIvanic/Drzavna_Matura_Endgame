package com.example.drzavnamatura_endgame;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;


import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.drawable.Drawable;
import android.media.MediaPlayer;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;

import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.Toast;

import com.example.drzavnamatura_endgame.GameDirectory.GameActivity;
import com.example.drzavnamatura_endgame.MainFragments.CjelineFragment;
import com.example.drzavnamatura_endgame.MainFragments.CompeteFragment;
import com.example.drzavnamatura_endgame.MainFragments.GradivaFragment;
import com.example.drzavnamatura_endgame.MainFragments.HomeFragment;
import com.example.drzavnamatura_endgame.MainFragments.LeckijaFragment;
import com.example.drzavnamatura_endgame.MainFragments.ProfileFragment;
import com.example.drzavnamatura_endgame.MainFragments.SearchFragment;
import com.example.drzavnamatura_endgame.MainFragments.SettingsFragment;
import com.example.drzavnamatura_endgame.MainFragments.ShopFragment;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import static com.example.drzavnamatura_endgame.MainActivity.completeInfo2;


public class MainMenuActivity extends AppCompatActivity {
    FirebaseFirestore db = FirebaseFirestore.getInstance();
    FirebaseUser currentUser;
    FirebaseAuth mAuth;
    private CollectionReference usersCollectionRef = db.collection("users");

    public static String gradivoPosition;
    BottomNavigationView bottomNavigationView;

    String TAG = "Find me";

    boolean pressed;
    public static Fragment currentF;
    public static int kojiFragment;

    public static String currentUserUsername = "";
    public static String currentUserEmail = "";

    public static MediaPlayer mediaPlayer;
    public static boolean musicEnabled;

    public static boolean isMusicPlaying = false;

    public static String completeInfo = "";

    public static boolean setHomeOnClick = true;

    SharedPreferences sharedPreferences;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        requestWindowFeature(Window.FEATURE_NO_TITLE);

        //BOJA STATUS BARA
        Window window = getWindow();
        window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
        window.setStatusBarColor(ContextCompat.getColor(this, R.color.statusBarColor));

        window.setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FORCE_NOT_FULLSCREEN);

        setContentView(R.layout.activity_main_menu);

        if (!completeInfo2.isEmpty()) {
            completeInfo = completeInfo2;
            completeInfo2 = "";
        }

        mAuth = FirebaseAuth.getInstance();
        currentUser = mAuth.getCurrentUser();
        bottomNavigationView = findViewById(R.id.bottomNavigationBar);
        currentUserUsername = currentUser.getDisplayName();
        currentUserEmail = currentUser.getEmail();

        updateProfileFragment();


        sharedPreferences = this.getSharedPreferences("com.example.drzavnamatura_endgame", MODE_PRIVATE);
        if (mediaPlayer == null) {
            mediaPlayer = MediaPlayer.create(getApplicationContext(), R.raw.background_music);
        }

        mediaPlayer.setLooping(true);

        //sharedPreferences.edit().clear().apply();

        if (!sharedPreferences.contains("musicEnabled")) {
            sharedPreferences.edit().putBoolean("musicEnabled", true).apply();
        }
        musicEnabled = sharedPreferences.getBoolean("musicEnabled", false);
        sharedPreferences.edit().putBoolean("isMusicPlaying", isMusicPlaying).apply();
        if (musicEnabled && !isMusicPlaying) {
            mediaPlayer.start();
        }


        try {
            final ArrayList<String> emails = new ArrayList<>();
            usersCollectionRef.get().addOnSuccessListener(new OnSuccessListener<QuerySnapshot>() {
                @Override
                public void onSuccess(QuerySnapshot queryDocumentSnapshots) {
                    List<DocumentSnapshot> documentSnapshots = queryDocumentSnapshots.getDocuments();
                    for (int i = 0; i < documentSnapshots.size(); i++) {
                        DocumentSnapshot documentSnapshot = documentSnapshots.get(i);
                        String objects = Objects.requireNonNull(documentSnapshot.get("email")).toString();
                        Log.d(TAG, "onSuccess: " + objects);
                        emails.add(objects);
                    }
                    Log.i("emails", "wowo" + emails);
                }
            });
        } catch (Exception e) {
            e.printStackTrace();
        }


        //BOTTOM NAVIGATION BAR FRAGMENT PICKER
        bottomNavigationView.setSelectedItemId(R.id.navigation_home);
        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                if (item.getItemId() != R.id.navigation_home) {
                    setHomeOnClick = false;
                }
                switch (item.getItemId()) {
                    case R.id.navigation_home:
                        if (setHomeOnClick) {
                            sharedPreferences.edit().putInt("kojiFragment", 0).apply();
                        }
                        sjetiSeGdjeSiStao();
                        return true;
                    case R.id.navigation_compete:
                        currentF = CompeteFragment.newInstance("", "");
                        openFragment(currentF);
                        return true;
                    case R.id.navigation_profile:
                        currentF = ProfileFragment.newInstance("", "");
                        openFragment(currentF);
                        return true;
                    case R.id.navigation_search:
                        currentF = SearchFragment.newInstance("", "");
                        openFragment(currentF);
                        return true;
                    case R.id.navigation_shop:
                        currentF = ShopFragment.newInstance("", "");
                        openFragment(currentF);
                        return true;
                }

                return false;
            }
        });

        sjetiSeGdjeSiStao();
    }


    public void sjetiSeGdjeSiStao() {
        switch (sharedPreferences.getInt("kojiFragment", 0)) {
            case 0:
                pressed = false;  //ZA IZLAZ IZ APLIKACIJE
                currentF = HomeFragment.newInstance("", "");
                break;
            case 1:
                currentF = new GradivaFragment();
                break;
            case 2:
                currentF = new CjelineFragment();
                break;
            case 3:
                currentF = new LeckijaFragment();
                break;
        }
        setHomeOnClick = true;
        openFragment(currentF);
    }

    public void openFragment(Fragment fragment) {
        FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
        transaction.replace(R.id.fragment_container, fragment);
        transaction.commit();
    }


    public void openGradiva(View v) {
        GradivaFragment gradivaFragment = new GradivaFragment();
        FragmentManager fragmentManager1 = getSupportFragmentManager();
        FragmentTransaction fragmentTransaction1 = fragmentManager1.beginTransaction();
        //pamtiGdjeSiStao();
        fragmentTransaction1.addToBackStack(null);
        fragmentTransaction1.remove(currentF);
        currentF = gradivaFragment;
        fragmentTransaction1.add(R.id.fragment_container, gradivaFragment, "gradiva").commit();

    }

    public void openCjeline() {
        CjelineFragment cjelineFragment = new CjelineFragment();
        FragmentManager fragmentManager1 = getSupportFragmentManager();
        FragmentTransaction fragmentTransaction1 = fragmentManager1.beginTransaction();
        ///  pamtiGdjeSiStao();
        fragmentTransaction1.addToBackStack(null);
        fragmentTransaction1.remove(currentF);
        currentF = cjelineFragment;
        fragmentTransaction1.add(R.id.fragment_container, cjelineFragment, "cjeline").commit();
    }


    public void openGame1v1(View view) {
        Intent intent = new Intent(MainMenuActivity.this, GameActivity.class);
        startActivity(intent);
    }

    @Override
    public void onBackPressed() {


        switch (sharedPreferences.getInt("kojiFragment", 0)) {
            case 0:
                if (!pressed) {
                    Toast.makeText(this, "Press again to exit", Toast.LENGTH_SHORT).show();
                    pressed = true;
                } else {
                    finish();
                }
                break;
            case 1:
                pressed = false;  //ZA IZLAZ IZ APLIKACIJE
                currentF = HomeFragment.newInstance("", "");
                openFragment(currentF);
                break;
            case 2:

                openGradiva(null);


                break;
            case 3:
                openCjeline();
                break;


        }
    }

    public void openSettings(View view) {
        Intent intent = new Intent(MainMenuActivity.this, SettingsActivity.class);
        startActivity(intent);
    }

    public void updateProfileFragment() {
        if (completeInfo2.isEmpty()) {
            try {
                usersCollectionRef.get().addOnSuccessListener(new OnSuccessListener<QuerySnapshot>() {
                    @Override
                    public void onSuccess(QuerySnapshot queryDocumentSnapshots) {
                        List<DocumentSnapshot> documentSnapshots = queryDocumentSnapshots.getDocuments();
                        for (int i = 0; i < documentSnapshots.size(); i++) {
                            DocumentSnapshot documentSnapshot = documentSnapshots.get(i);
                            String score = Objects.requireNonNull(documentSnapshot.get("score")).toString();
                            String usernameCurrent = Objects.requireNonNull(documentSnapshot.get("username")).toString();
                            if (usernameCurrent.equals(currentUser.getDisplayName())) {
                                completeInfo = currentUserUsername + ", Score: " + score;
                                completeInfo2 = "";
                            }
                        }

                    }
                }).addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Toast.makeText(getApplicationContext(), e.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                });
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    public void signOut(View view) {
        mAuth.signOut();
        mediaPlayer.stop();
        Intent intent = new Intent(MainMenuActivity.this, LoginActivity.class);
        startActivity(intent);
        finish();
    }



    @Override
    protected void onDestroy() {
        super.onDestroy();
        mediaPlayer.stop();
        sharedPreferences.edit().putBoolean("isMusicPlaying", false).apply();
    }
}

