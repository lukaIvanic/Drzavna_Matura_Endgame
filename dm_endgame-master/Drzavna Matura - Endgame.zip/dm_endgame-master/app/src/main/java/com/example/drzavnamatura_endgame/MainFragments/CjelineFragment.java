package com.example.drzavnamatura_endgame.MainFragments;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.drzavnamatura_endgame.Lekcija;
import com.example.drzavnamatura_endgame.R;
import com.example.drzavnamatura_endgame.RecyclerViewHelper.RecyclerAdapter;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import static android.content.Context.MODE_PRIVATE;
import static com.example.drzavnamatura_endgame.MainMenuActivity.currentF;
import static com.example.drzavnamatura_endgame.MainMenuActivity.gradivoPosition;
import static com.example.drzavnamatura_endgame.MainMenuActivity.kojiFragment;


public class CjelineFragment extends Fragment implements RecyclerAdapter.OnItemListener {

    private List<Lekcija> listCjelina;
    ArrayList<Lekcija> testic = new ArrayList<>();

    private FirebaseFirestore database = FirebaseFirestore.getInstance();

    private CollectionReference collectionReference = database.collection("lekcije");

    public static int layout_lekcije;
    public static Lekcija lekcija;

    public CjelineFragment() {
        kojiFragment = 2;
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_sve_cjeline, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {


        SharedPreferences sharedPreferences = Objects.requireNonNull(this.getActivity()).getSharedPreferences("com.example.drzavnamatura_endgame", MODE_PRIVATE);
        sharedPreferences.edit().remove("kojiFragment").apply();
        sharedPreferences.edit().putInt("kojiFragment", 2).apply();
        Toast.makeText(getContext(), "Fragment: " + sharedPreferences.getInt("kojiFragment", 0), Toast.LENGTH_SHORT).show();
        Log.i("DAP CijelineFragmnet", sharedPreferences.getInt("kojiFragment", 0) + "");

        final RecyclerView recyclerView = view.findViewById(R.id.recyclerCjeline);
        TextView textView = view.findViewById(R.id.bigNaslovCjeline);
        textView.setText(gradivoPosition);
        listCjelina = new ArrayList<>();

        final LinearLayoutManager layoutManager = new GridLayoutManager(getActivity(), 2);
        final RecyclerAdapter adapter = new RecyclerAdapter(getActivity(), listCjelina, 1, this);
        recyclerView.setLayoutManager(layoutManager);
        recyclerView.setAdapter(adapter);
        listCjelina.clear();
        testic.clear();

        collectionReference.get().addOnSuccessListener(new OnSuccessListener<QuerySnapshot>() {
            @Override
            public void onSuccess(QuerySnapshot queryDocumentSnapshots) {
                if (!queryDocumentSnapshots.isEmpty()) {

                    for (QueryDocumentSnapshot lekcijeGetter : queryDocumentSnapshots) {

                        lekcija_type_checker(lekcijeGetter);    //prikladno deklarira globalnu varijablu lekcija

                        testic.add(lekcija);    //tu se dodaje u listu
                    }

                } else {
                    Toast.makeText(getContext(), "Dokumenti u 'Lekcije' su prazni", Toast.LENGTH_SHORT).show();
                }


            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                Toast.makeText(getContext(), "OnFailureActivated", Toast.LENGTH_SHORT).show();
            }
        }).addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
            @Override
            public void onComplete(@NonNull Task<QuerySnapshot> task) {

                listCjelina.addAll(testic);
                adapter.notifyDataSetChanged();

                for (Lekcija checker : testic) {
                    if (checker.getSlikaURL() != null) {
                        Log.i("LOGGED ", checker.getSlikaURL());
                    }
                }
            }
        });


    }

    @Override
    public void onItemClick(final int position) {

        Toast.makeText(getContext(), "Position: " + position, Toast.LENGTH_SHORT).show();

        lekcija = testic.get(position);

        if (lekcija.getSadrzaj() != null) {
            if (lekcija.getSlikaURL() != null) {
                lekcija = new Lekcija(lekcija.getNaslov(), lekcija.getSadrzaj(), lekcija.getSlikaURL());
            } else {
                lekcija = new Lekcija(lekcija.getNaslov(), lekcija.getSadrzaj());
            }
        } else {
            lekcija = new Lekcija(lekcija.getNaslov());
        }


        layoutChooser(lekcija.getTIP_LEKCIJE());

        LeckijaFragment lekcijaFragment = new LeckijaFragment();
        currentF = lekcijaFragment;
        assert getFragmentManager() != null;
        FragmentTransaction fragmentTransaction = getFragmentManager().beginTransaction();
        fragmentTransaction.addToBackStack(null);
        fragmentTransaction.replace(R.id.fragment_container, lekcijaFragment, "cjeline");
        fragmentTransaction.commit();


    }


    public void layoutChooser(String tip_lekcije) {
        //BIRA ODREĐEN LAYOUT
        switch (tip_lekcije) {
            case Lekcija.SAMO_NASLOV:
                layout_lekcije = R.layout.fragment_leckija_samo_naslov;
                ;
                break;

            case Lekcija.NASLOV_SADRZAJ:
                layout_lekcije = R.layout.fragment_lekcija_naslov_sadrzaj;
                break;

            case Lekcija.NASLOV_SADRZAJ_SLIKA:
                layout_lekcije = R.layout.fragment_leckija_2tekst_1slika;
                break;
        }
    }

    public void lekcija_type_checker(QueryDocumentSnapshot lekcijeGetter) {
        //Checka sto lekcija sadrzi i daje informacije prikladnom konstruktoru
        //To se radi zbog jednostavnosti u dodavanju lekcija
        switch (lekcijeGetter.getString("tip")) {
            case "0":
                lekcija = new Lekcija(lekcijeGetter.getString("Naslov"));
                break;
            case "1":
                lekcija = new Lekcija(lekcijeGetter.getString("Naslov"), lekcijeGetter.getString("sadrzaj"));
                break;
            case "2":
                lekcija = new Lekcija(lekcijeGetter.getString("Naslov"), lekcijeGetter.getString("sadrzaj"), lekcijeGetter.getString("imageURL"));
                break;
        }
//        }
//        if (lekcijeGetter.getString("sadrzaj") != null) {
//
//            if (lekcijeGetter.getString("imageURL") != null) {
//                lekcija = new Lekcija(lekcijeGetter.getString("Naslov"), lekcijeGetter.getString("sadrzaj"), lekcijeGetter.getString("imageURL"));
//            } else {
//                lekcija = new Lekcija(lekcijeGetter.getString("Naslov"), lekcijeGetter.getString("sadrzaj"));
//            }
//        } else {
//            lekcija = new Lekcija(lekcijeGetter.getString("Naslov"));
//        }
    }
}

