package com.example.drzavnamatura_endgame.MainFragments;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.drzavnamatura_endgame.Lekcija;
import com.example.drzavnamatura_endgame.R;
import com.squareup.picasso.Picasso;

import java.util.Objects;

import static android.content.Context.MODE_PRIVATE;
import static com.example.drzavnamatura_endgame.MainFragments.CjelineFragment.layout_lekcije;
import static com.example.drzavnamatura_endgame.MainFragments.CjelineFragment.lekcija;
import static com.example.drzavnamatura_endgame.MainMenuActivity.kojiFragment;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link LeckijaFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class LeckijaFragment extends Fragment {

    public LeckijaFragment() {
    }

    public static LeckijaFragment newInstance(String param1, String param2) {
        LeckijaFragment fragment = new LeckijaFragment();
        return fragment;
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        return inflater.inflate(layout_lekcije, container, false);
    }

    TextView naslov, sadrzaj;
    ImageView slika;

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        SharedPreferences sharedPreferences = Objects.requireNonNull(this.getActivity()).getSharedPreferences("com.example.drzavnamatura_endgame", MODE_PRIVATE);
        sharedPreferences.edit().remove("kojiFragment").apply();
        sharedPreferences.edit().putInt("kojiFragment", 3).apply();

        Log.i("DAP LekcijaFragment", sharedPreferences.getInt("kojiFragment", 0) + "");

        try {
            naslov = view.findViewById(R.id.naslovLekcijeULekciji);
            naslov.setText(lekcija.getNaslov());

            switch (lekcija.getTIP_LEKCIJE()) {
                case Lekcija.NASLOV_SADRZAJ:
                    sadrzaj = view.findViewById(R.id.sadrzajLekcije);
                    sadrzaj.setText(lekcija.getSadrzaj());
                    break;
                case Lekcija.NASLOV_SADRZAJ_SLIKA:
                    sadrzaj = view.findViewById(R.id.sadrzajLekcije);
                    sadrzaj.setText(lekcija.getSadrzaj());

                    slika = view.findViewById(R.id.slikaLekcije);

                    break;


            }
        } catch (Exception e) {
            e.printStackTrace();
        }

    }
}
