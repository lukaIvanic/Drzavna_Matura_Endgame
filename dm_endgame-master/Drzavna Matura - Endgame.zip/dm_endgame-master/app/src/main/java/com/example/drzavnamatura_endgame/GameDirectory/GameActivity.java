package com.example.drzavnamatura_endgame.GameDirectory;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import com.example.drzavnamatura_endgame.R;

public class GameActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game);
    }

    public void proceedWithGame(View view) {
        Intent intent = new Intent(GameActivity.this, GameActivity2.class);
        startActivity(intent);
    }
}
