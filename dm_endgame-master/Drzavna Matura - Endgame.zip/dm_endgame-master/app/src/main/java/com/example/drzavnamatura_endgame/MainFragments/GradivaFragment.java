package com.example.drzavnamatura_endgame.MainFragments;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.drzavnamatura_endgame.RecyclerViewHelper.RecyclerAdapter;
import com.example.drzavnamatura_endgame.RecyclerViewHelper.GradivoItem;
import com.example.drzavnamatura_endgame.R;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import static android.content.Context.MODE_PRIVATE;
import static com.example.drzavnamatura_endgame.MainMenuActivity.currentF;
import static com.example.drzavnamatura_endgame.MainMenuActivity.gradivoPosition;
import static com.example.drzavnamatura_endgame.MainMenuActivity.kojiFragment;

public class GradivaFragment extends Fragment implements RecyclerAdapter.OnItemListener {

    private List<GradivoItem> listGradiva;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_sva_gradiva, container, false);


    }

    public GradivaFragment() {
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {

        SharedPreferences sharedPreferences = Objects.requireNonNull(this.getActivity()).getSharedPreferences("com.example.drzavnamatura_endgame", MODE_PRIVATE);
        sharedPreferences.edit().remove("kojiFragment").apply();
        sharedPreferences.edit().putInt("kojiFragment", 1).apply();
        Toast.makeText(getContext(), "Fragment: " + sharedPreferences.getInt("kojiFragment", 0), Toast.LENGTH_SHORT).show();
        Log.i("DAP GradivaFragment", sharedPreferences.getInt("kojiFragment", 0) + "");


        RecyclerView recyclerGradiva = view.findViewById(R.id.recyclerViewGradiva);

        listGradiva = new ArrayList<>();
        listGradiva.add(new GradivoItem(R.drawable.slika_za_iteme, "Brojevi"));
        listGradiva.add(new GradivoItem("Funkcije"));
        listGradiva.add(new GradivoItem("Kurac"));
        listGradiva.add(new GradivoItem("Geometrija"));
        listGradiva.add(new GradivoItem("Neznan"));
        listGradiva.add(new GradivoItem("Derivacije"));
        listGradiva.add(new GradivoItem("Drugi Stupanj"));
        listGradiva.add(new GradivoItem("Naslov"));

        final LinearLayoutManager layoutManager = new GridLayoutManager(getActivity(), 2);


        //adapter
        RecyclerAdapter adapter = new RecyclerAdapter(getActivity(), listGradiva, this);
        recyclerGradiva.setLayoutManager(layoutManager);
        recyclerGradiva.setAdapter(adapter);


    }



    @Override
    public void onItemClick(int position) {


        gradivoPosition = listGradiva.get(position).getNaslov();
        CjelineFragment cjelineFragment = new CjelineFragment();
        currentF = cjelineFragment;
        assert getFragmentManager() != null;
        FragmentTransaction fragmentTransaction = getFragmentManager().beginTransaction();
        fragmentTransaction.addToBackStack(null);
        fragmentTransaction.replace(R.id.fragment_container, cjelineFragment, "cjeline");
        fragmentTransaction.commit();


    }
}
