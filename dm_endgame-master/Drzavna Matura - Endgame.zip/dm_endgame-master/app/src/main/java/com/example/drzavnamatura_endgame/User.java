package com.example.drzavnamatura_endgame;

public class User {
    private String username;
    private String email;
    private String userID;
    private String score;
    private boolean isMale;
    private int profilePictureDrawable;


    public User(String username, String email, String userID, String score, boolean isMale, int profilePictureDrawable) {
        this.username = username;
        this.email = email;
        this.userID = userID;
        this.score = score;
        this.isMale = isMale;
        this.profilePictureDrawable = profilePictureDrawable;
    }

    public User(String username, String email, String userID, String score, boolean isMale) {
        this.username = username;
        this.email = email;
        this.userID = userID;
        this.score = score;
        this.isMale = isMale;
    }

    public int getProfilePictureDrawable() {
        return profilePictureDrawable;
    }

    public void setProfilePictureDrawable(int profilePictureDrawable) {
        this.profilePictureDrawable = profilePictureDrawable;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getUserID() {
        return userID;
    }

    public void setUserID(String userID) {
        this.userID = userID;
    }

    public String getScore() {
        return score;
    }

    public void setScore(String score) {
        this.score = score;
    }

    public boolean isMale() {
        return isMale;
    }

    public void setMale(boolean male) {
        isMale = male;
    }

}
