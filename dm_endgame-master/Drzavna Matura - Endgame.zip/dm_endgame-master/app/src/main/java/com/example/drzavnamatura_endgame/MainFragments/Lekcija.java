package com.example.drzavnamatura_endgame.MainFragments;

import android.net.Uri;
import android.widget.ImageView;

public class Lekcija {
    String naslov = "", sadrzaj = "";
    Uri slika;

    public Lekcija(String naslov) {
        this.naslov = naslov;
    }

    public Lekcija(String naslov, String sadrzaj) {
        this.naslov = naslov;
        this.sadrzaj = sadrzaj;
    }

    public Lekcija(String naslov, String sadrzaj, Uri slika) {
        this.naslov = naslov;
        this.sadrzaj = sadrzaj;
        this.slika = slika;
    }
}
